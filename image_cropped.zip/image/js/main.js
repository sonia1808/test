window.onload = function () {

  

  var Cropper = window.Cropper;
  var URL = window.URL || window.webkitURL;
  var container = document.querySelector('.img-container');
  var image = container.getElementsByTagName('img').item(0);
  // var actions = document.getElementById('actions');
  var dataX = document.getElementById('dataX');
  var dataY = document.getElementById('dataY');
  var dataHeight = document.getElementById('dataHeight');
  var dataWidth = document.getElementById('dataWidth');
  var dataRotate = document.getElementById('dataRotate');
  var dataScaleX = document.getElementById('dataScaleX');
  var dataScaleY = document.getElementById('dataScaleY');
  var options = {
    aspectRatio: 16 / 9,
    preview: '.img-preview',
    ready: function (e) {
      //console.log(e.type);
    },
    cropstart: function (e) {
      //console.log(e.type, e.detail.action);
    },
    cropmove: function (e) {
     // console.log(e.type, e.detail.action);
    },
    cropend: function (e) {
      //console.log(e.type, e.detail.action);
    },
    crop: function (e) {
      var data = e.detail;

        //console.log(e.type);
        dataX.value = Math.round(data.x);
        dataY.value = Math.round(data.y);
        dataHeight.value = Math.round(data.height);
        dataWidth.value = Math.round(data.width);
        dataRotate.value = typeof data.rotate !== 'undefined' ? data.rotate : '';
        dataScaleX.value = typeof data.scaleX !== 'undefined' ? data.scaleX : '';
        dataScaleY.value = typeof data.scaleY !== 'undefined' ? data.scaleY : '';

        var canvas = cropper.getCroppedCanvas({
          width: 160,
          height: 90,
          minWidth: 256,
          minHeight: 256,
          maxWidth: 4096,
          maxHeight: 4096,
          fillColor: '#000',
          imageSmoothingEnabled: false,
          imageSmoothingQuality: 'high',
        });

        // console.log(canvas);
        var imgUrlBase64 = canvas.toDataURL();
        jQuery("#profile_picture").attr('src', imgUrlBase64 );
        jQuery("#imageBase64").val( imgUrlBase64 );

        // console.log(canvas.toDataURL());

         // Use `jQuery.ajax` method
          /*$.ajax({
              url: "save_image.php", 
              method:'POST',
              data  : {"imageBase64": imgUrlBase64},
              success: function(result){

              console.log(result);


              }
          });*/
       /* $.ajax('save_image.php', {
          method: "POST",
          data: {"imageBase64": imgUrlBase64},
          processData: false,
          contentType: false,
          success: function (res) {

            console.log(res);
            console.log('Upload success');
          },
          error: function () {
            console.log('Upload error');
          }
        });*/

        // ==========================================
         // var canvas = document.getElementById('canvas');
         // console.log(canvas);

          /*canvas.toBlob(function(blob) {
            var newImg = document.createElement('img'),
                url = URL.createObjectURL(blob);

            newImg.onload = function() {
              // no longer need to read the blob so it's revoked
              URL.revokeObjectURL(url);
            };

            newImg.src = url;
            console.log("urlurlurlurlurlurl");
            console.log(url);
            console.log(newImg);

            // document.body.appendChild(newImg);
          });*/

        // ==========================================
       /* cropper.getCroppedCanvas({
          width: 160,
          height: 90,
          minWidth: 256,
          minHeight: 256,
          maxWidth: 4096,
          maxHeight: 4096,
          fillColor: '#000',
          imageSmoothingEnabled: false,
          imageSmoothingQuality: 'high',
        }).toBlob(function (blob) {

           // console.log("blob blob blobblobblobblobblobblob");
           console.log(blob);
        var formData = new FormData();
        

        formData.append('croppedImage', blob);
        console.log(formData);
        // Use `jQuery.ajax` method
        $.ajax('save_image.php', {
          method: "POST",
          data: formData,
          processData: false,
          contentType: false,
          success: function (res) {

            console.log(res);
            console.log('Upload success');
          },
          error: function () {
            console.log('Upload error');
          }
        });
      });*/

   


    },
    zoom: function (e) {
      console.log(e.type, e.detail.ratio);
    }
  };
  var cropper = new Cropper(image, options);
  
  var originalImageURL = image.src;
  var uploadedImageType = 'image/jpeg';
  var uploadedImageURL;

  // Tooltip
  $('[data-toggle="tooltip"]').tooltip();

  // Buttons
  if (!document.createElement('canvas').getContext) {
    $('button[data-method="getCroppedCanvas"]').prop('disabled', true);
  }

  if (typeof document.createElement('cropper').style.transition === 'undefined') {
    $('button[data-method="rotate"]').prop('disabled', true);
    $('button[data-method="scale"]').prop('disabled', true);
  }



  document.body.onkeydown = function (event) {
    var e = event || window.event;

    if (!cropper || this.scrollTop > 300) {
      return;
    }

    switch (e.keyCode) {
      case 37:
        e.preventDefault();
        cropper.move(-1, 0);
        break;

      case 38:
        e.preventDefault();
        cropper.move(0, -1);
        break;

      case 39:
        e.preventDefault();
        cropper.move(1, 0);
        break;

      case 40:
        e.preventDefault();
        cropper.move(0, 1);
        break;
    }
  };




  /* When click on change profile pic */  
  jQuery('#change-profile-pic').on('click', function(e){
        jQuery('#profile_pic_modal').modal({show:true});        
    }); 

  jQuery('#profile-pic').on('change', function()  { 
    jQuery("#preview-profile-pic").html('');
    jQuery("#preview-profile-pic").html('Uploading....');
    jQuery("#cropimage").ajaxForm(
    {
    success:    function(res) {
        
        jQuery("#save_crop").attr('disabled', false);

        cropper.replace( res );
    
    }
    }).submit();

  });
  //Save cropped image
  jQuery('#save_crop').on('click', function() { 
        var croppedImgBase64 = jQuery("#imageBase64").val();
        // alert();
          $.ajax({
                url: "save_image.php", 
                method:'POST',
                data  : {"imageBase64": croppedImgBase64},
                success: function(result){
                       console.log(result);
                  }
            });
      
  });


};
