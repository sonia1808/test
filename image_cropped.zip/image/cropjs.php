<?php include("db_connect.php"); ?>
<!DOCTYPE>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Cropper.js</title>
  <link rel="stylesheet" href="dist/cropper.css">
  <style>
    .container {
      max-width: 640px;
      margin: 20px auto;
    }

    img {
      width: 100%;
    }
  </style>
</head>
<body>

  <div class="container">
    <h1>Cropper with responsive container</h1>
    <p>
      <button type="button" id="replace">Replace Image</button>
    </p>
    <div>
      <img id="image" src="docs/images/picture.jpg" alt="Picture">
    </div>
  </div>

  <script src="dist/cropper.js"></script>
  <script>
    window.addEventListener('DOMContentLoaded', function () {
      var image = document.querySelector('#image');
      var cropper = new Cropper(image, {
        movable: false,
        zoomable: false,
        rotatable: false,
        scalable: false
      });

      document.getElementById('replace').onclick = function () {
        cropper.replace('docs/images/picture-2.jpg');
      };
    });
  </script>
</body>
</html>
